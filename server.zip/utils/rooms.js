const rooms = []

const createRoom = () => {
    rooms.push()
}